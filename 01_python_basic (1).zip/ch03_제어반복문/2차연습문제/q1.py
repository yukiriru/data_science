LIMIT=100
for i in range(1, LIMIT+1):
    print(i)