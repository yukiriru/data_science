count = 0

while True:
    count += 1
    print(f"현재 count: {count}")

    if count >= 5:
        print("count가 5 이상이므로 루프를 종료합니다.")
        break
