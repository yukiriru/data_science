num = int(input("정수를 입력하세요: "))

if num % 2 == 0:
    print(num, "은(는) 짝수입니다.")
else:
    print(num, "은(는) 홀수입니다.")
