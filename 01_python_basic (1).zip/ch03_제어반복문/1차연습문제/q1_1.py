num1 = int(input("첫 번째 수를 입력하세요: "))
num2 = int(input("두 번째 수를 입력하세요: "))

sum = num1 + num2

print(f"두 수의 합은 {sum}입니다.")
