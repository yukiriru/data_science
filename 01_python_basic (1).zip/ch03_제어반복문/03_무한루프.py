while True:
     print("무한루프 수행중")