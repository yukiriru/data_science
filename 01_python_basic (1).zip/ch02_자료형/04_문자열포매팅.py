name = 'jane'
age = 22
str = '나의 이름은 '+name+'입니다. 나이는 '+str(age)+'입니다.'
print(str)

f_str = f'나의 이름은 {name}입니다. 나이는 {age}입니다.'
print(f_str)