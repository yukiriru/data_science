a = 123

print(type(a))

a = 3.14
print(type(a))