a = 3
b = 4
a+b
print(a + b)
print(a - b)