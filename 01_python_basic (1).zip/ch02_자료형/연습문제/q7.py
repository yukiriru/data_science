text = "Hello, World!"
substring = text[:5]
print(substring)
