text = "Hello, My Beautiful World!"
substring = text[-6:]
print(substring)
