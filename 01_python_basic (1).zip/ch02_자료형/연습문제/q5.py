string = "a:b:c:d"
replaced_string = string.replace(":", "#")
print(replaced_string)
