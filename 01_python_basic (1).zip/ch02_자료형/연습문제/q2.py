num = 13
if num % 2 == 0:
    print("0")  # Even number
else:
    print("1")  # Odd number

num2 = 16
if num2 % 2 == 0:
    print("0")  # Even number
else:
    print("1")  # Odd number