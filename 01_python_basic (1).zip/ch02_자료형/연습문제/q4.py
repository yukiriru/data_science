resident_registration = "881120-1068234"
gender = resident_registration[7]
print(gender)
