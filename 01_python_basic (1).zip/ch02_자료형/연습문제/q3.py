resident_registration = "881120-1068234"
date_part = resident_registration[:6]
number_part = resident_registration[7:]
print(date_part)
print(number_part)
