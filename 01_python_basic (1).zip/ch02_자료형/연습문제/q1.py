korean = 80
english = 75
math = 90
science = 95

average = (korean + english + math + science) / 4
print("평균 점수:", average)
