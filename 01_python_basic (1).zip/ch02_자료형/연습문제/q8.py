text = "Hello, World!"
substring = text[-1]
print(substring)
