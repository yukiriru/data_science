my_list = ['우리', '끝까지', '힘내요!']
# [‘우리’,’끝까지’,’힘내요!’]
['우리','끝까지','힘내요!']
string = ' '.join(my_list)

print(string)
