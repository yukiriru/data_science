secret_message = '파이팅! 하세요'

def add(a, b):
    return a + b
def sub(a, b):
    return a - b