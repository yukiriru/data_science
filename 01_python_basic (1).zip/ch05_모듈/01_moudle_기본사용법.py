import mod1

print(mod1.add(3,4))
print(mod1.sub(4,2))
print(mod1.secret_message)

print(mod1.add(2,4))