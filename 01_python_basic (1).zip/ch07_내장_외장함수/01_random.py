import random

odd_even  = random.randint(1,2)

if odd_even == 1:
    print("홀수")
else:
    print("짝수")