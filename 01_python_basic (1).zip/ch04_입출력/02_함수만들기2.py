
number1 = 10
number2 = 20
print("=" * 10)
print("입력값 확인")
print(f'number1: {number1}, number2: {number2}')
result = number1 + number2



print("="*10)
print("최종결과")
