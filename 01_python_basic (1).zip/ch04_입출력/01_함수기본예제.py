def add(a,b): # 함수 실행부/정의부: 함수가 호출 되었을 경우에만 실행
    result = a+b
    return result

a = 3
b = 4

result = add(a,b) # add(a,b) 함수 호출부
print(f'result: {result}')
