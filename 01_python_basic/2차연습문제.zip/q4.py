HEIGHT = 5
for star_count in range(1, HEIGHT+1):
    print('*' * star_count)